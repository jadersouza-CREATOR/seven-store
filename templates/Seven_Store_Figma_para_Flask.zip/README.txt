SEVEN STORE — conversão visual Figma -> Flask

Arquivos:
- static/style.css
- templates/inicio.html
- templates/pagina.html

Substitua os arquivos correspondentes no repositório Flask.
Não substitua app.py nem altere o banco.
O layout usa a estrutura visual do arquivo Figma: sidebar azul escura, dashboard com cards, gráficos, tabelas, alertas e atalhos.
